<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Jewellery Products</h1>

<a class="btn" href="add.php">
    + Add Product
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Name</th>
<th>Category</th>
<th>Metal</th>
<th>Purity</th>
<th>Weight</th>
<th>Price</th>
<th>Stock</th>
<th>Action</th>
</tr>

<?php

$result = $conn->query(
    "SELECT p.*, c.name AS category
     FROM products p
     LEFT JOIN categories c
     ON c.id = p.category_id
     ORDER BY p.id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td><?php echo htmlspecialchars($row['name']); ?></td>

<td><?php echo $row['category']; ?></td>

<td><?php echo $row['metal_type']; ?></td>

<td><?php echo $row['purity']; ?></td>

<td><?php echo $row['weight']; ?> g</td>

<td>
₹<?php echo number_format($row['price'], 2); ?>
</td>

<td><?php echo $row['stock']; ?></td>

<td>

<a class="btn"
href="edit.php?id=<?php echo $row['id']; ?>">
Edit
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>