<?php

require "../partials/header.php";
require "../config/db.php";

$id = (int)$_GET['id'];

$result = $conn->query(
    "SELECT *
     FROM products
     WHERE id = $id"
);

$product = $result->fetch_assoc();

if (!$product) {
    die("Product not found");
}

$categories = $conn->query(
    "SELECT * FROM categories ORDER BY name"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $category = (int)$_POST['category_id'];
    $metal = $_POST['metal_type'];
    $purity = $_POST['purity'];
    $weight = $_POST['weight'];
    $making = $_POST['making_charge'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    $stmt = $conn->prepare(
        "UPDATE products
         SET
            name=?,
            category_id=?,
            metal_type=?,
            purity=?,
            weight=?,
            making_charge=?,
            price=?,
            stock=?
         WHERE id=?"
    );

    $stmt->bind_param(
        "sissdddii",
        $name,
        $category,
        $metal,
        $purity,
        $weight,
        $making,
        $price,
        $stock,
        $id
    );

    $stmt->execute();

    header("Location: index.php");
    exit();
}

?>

<h1>Edit Product</h1>

<div class="form-box">

<form method="POST">

<label>Product Name</label>

<input
    name="name"
    value="<?php echo htmlspecialchars($product['name']); ?>"
    required
>

<label>Category</label>

<select name="category_id">

<?php while ($category = $categories->fetch_assoc()) { ?>

<option
value="<?php echo $category['id']; ?>"
<?php
if ($category['id'] == $product['category_id']) {
    echo "selected";
}
?>
>

<?php echo htmlspecialchars($category['name']); ?>

</option>

<?php } ?>

</select>

<label>Metal</label>

<select name="metal_type">

<?php

$metals = [
    "Gold",
    "Silver",
    "Diamond",
    "Other"
];

foreach ($metals as $metal) {

?>

<option
<?php
if ($metal == $product['metal_type']) {
    echo "selected";
}
?>
>

<?php echo $metal; ?>

</option>

<?php } ?>

</select>

<label>Purity</label>

<input
    name="purity"
    value="<?php echo htmlspecialchars($product['purity']); ?>"
>

<label>Weight</label>

<input
    type="number"
    step="0.001"
    name="weight"
    value="<?php echo $product['weight']; ?>"
>

<label>Making Charge</label>

<input
    type="number"
    step="0.01"
    name="making_charge"
    value="<?php echo $product['making_charge']; ?>"
>

<label>Price</label>

<input
    type="number"
    step="0.01"
    name="price"
    value="<?php echo $product['price']; ?>"
>

<label>Stock</label>

<input
    type="number"
    name="stock"
    value="<?php echo $product['stock']; ?>"
>

<br>

<button class="btn green">
    Update Product
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>