<?php

require "../partials/header.php";
require "../config/db.php";

$categories = $conn->query(
    "SELECT * FROM categories ORDER BY name"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $category = (int)$_POST['category_id'];
    $metal = $_POST['metal_type'];
    $purity = $_POST['purity'];
    $weight = $_POST['weight'];
    $making = $_POST['making_charge'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    $stmt = $conn->prepare(
        "INSERT INTO products
        (
            name,
            category_id,
            metal_type,
            purity,
            weight,
            making_charge,
            price,
            stock
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "sissdddi",
        $name,
        $category,
        $metal,
        $purity,
        $weight,
        $making,
        $price,
        $stock
    );

    $stmt->execute();

    header("Location: index.php");
    exit();
}

?>

<h1>Add Jewellery Product</h1>

<div class="form-box">

<form method="POST">

<div class="grid2">

<div>

<label>Product Name</label>

<input
    name="name"
    required
>

</div>

<div>

<label>Category</label>

<select name="category_id">

<?php while ($category = $categories->fetch_assoc()) { ?>

<option value="<?php echo $category['id']; ?>">

<?php echo htmlspecialchars($category['name']); ?>

</option>

<?php } ?>

</select>

</div>

<div>

<label>Metal Type</label>

<select name="metal_type">

<option>Gold</option>
<option>Silver</option>
<option>Diamond</option>
<option>Other</option>

</select>

</div>

<div>

<label>Purity</label>

<input
    name="purity"
    placeholder="22K"
>

</div>

<div>

<label>Weight (grams)</label>

<input
    type="number"
    step="0.001"
    name="weight"
>

</div>

<div>

<label>Making Charge</label>

<input
    type="number"
    step="0.01"
    name="making_charge"
>

</div>

<div>

<label>Selling Price</label>

<input
    type="number"
    step="0.01"
    name="price"
>

</div>

<div>

<label>Stock Quantity</label>

<input
    type="number"
    name="stock"
>

</div>

</div>

<br>

<button class="btn green">
    Save Product
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>