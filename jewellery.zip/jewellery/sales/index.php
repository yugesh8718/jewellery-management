<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Sales</h1>

<a class="btn" href="add.php">
+ New Sale
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Invoice</th>
<th>Customer</th>
<th>Date</th>
<th>Total</th>
<th>Action</th>
</tr>

<?php

$result = $conn->query(
    "SELECT s.*, c.name AS customer
     FROM sales s
     LEFT JOIN customers c
     ON c.id=s.customer_id
     ORDER BY s.id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td><?php echo $row['invoice_no']; ?></td>

<td>
<?php
echo htmlspecialchars(
    $row['customer'] ?? 'Walk-in'
);
?>
</td>

<td><?php echo $row['sale_date']; ?></td>

<td>
₹<?php echo number_format($row['total'], 2); ?>
</td>

<td>

<a class="btn"
href="invoice.php?id=<?php echo $row['id']; ?>">
Invoice
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>