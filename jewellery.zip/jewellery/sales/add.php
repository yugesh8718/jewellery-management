<?php

require_once "../config/db.php";
require_once "../config/auth.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Customer
    if (isset($_POST['customer_id']) && $_POST['customer_id'] !== "") {
        $customer_id = (int) $_POST['customer_id'];
    } else {
        $customer_id = null;
    }

    // Product
    $product_id = isset($_POST['product_id'])
        ? (int) $_POST['product_id']
        : 0;

    // Quantity
    $quantity = isset($_POST['quantity'])
        ? (int) $_POST['quantity']
        : 0;

    // Price
    $price = isset($_POST['price'])
        ? (float) $_POST['price']
        : 0;

    // Sale date
    $sale_date = isset($_POST['sale_date']) && $_POST['sale_date'] !== ""
        ? $_POST['sale_date']
        : date("Y-m-d");


    // Basic validation
    if ($product_id <= 0) {

        $error = "Please select a product.";

    } elseif ($quantity <= 0) {

        $error = "Quantity must be greater than 0.";

    } elseif ($price <= 0) {

        $error = "Price must be greater than 0.";

    } else {

        // Check product stock
        $stockStmt = $conn->prepare(
            "SELECT stock, name
             FROM products
             WHERE id = ?
             LIMIT 1"
        );

        $stockStmt->bind_param("i", $product_id);
        $stockStmt->execute();

        $stockStmt->store_result();

        if ($stockStmt->num_rows == 0) {

            $error = "Selected product does not exist.";

        } else {

            $stockStmt->bind_result($available_stock, $product_name);
            $stockStmt->fetch();

            if ($quantity > $available_stock) {

                $error = "Not enough stock. Available stock: " . $available_stock;

            } else {

                // Calculate total
                $total = $quantity * $price;

                // Generate invoice number
                $invoice_no = "INV-" . date("YmdHis");


                // Insert sale
                $stmt = $conn->prepare(
                    "INSERT INTO sales
                    (invoice_no, customer_id, sale_date, total)
                    VALUES (?, ?, ?, ?)"
                );

                /*
                 * "sisd"
                 * s = invoice_no
                 * i = customer_id
                 * s = sale_date
                 * d = total
                 */

                $stmt->bind_param(
                    "sisd",
                    $invoice_no,
                    $customer_id,
                    $sale_date,
                    $total
                );


                if ($stmt->execute()) {

                    $sale_id = $conn->insert_id;


                    // Insert sale item
                    $itemStmt = $conn->prepare(
                        "INSERT INTO sale_items
                        (sale_id, product_id, quantity, price, subtotal)
                        VALUES (?, ?, ?, ?, ?)"
                    );

                    $itemStmt->bind_param(
                        "iiidd",
                        $sale_id,
                        $product_id,
                        $quantity,
                        $price,
                        $total
                    );


                    if ($itemStmt->execute()) {

                        // Reduce stock
                        $updateStock = $conn->prepare(
                            "UPDATE products
                             SET stock = stock - ?
                             WHERE id = ?"
                        );

                        $updateStock->bind_param(
                            "ii",
                            $quantity,
                            $product_id
                        );

                        $updateStock->execute();

                        // Success
                        header("Location: index.php");
                        exit();

                    } else {

                        $error = "Sale item could not be added: "
                               . $itemStmt->error;
                    }

                } else {

                    $error = "Sale could not be added: "
                           . $stmt->error;
                }
            }
        }
    }
}

?>

<?php require "../partials/header.php"; ?>


<div class="page-head">

    <h1>Add Sale</h1>

</div>


<?php if ($error != "") { ?>

    <div class="alert danger">

        <?php echo htmlspecialchars($error); ?>

    </div>

<?php } ?>


<div class="form-box">

    <form method="POST" action="">


        <!-- CUSTOMER -->

        <label>Customer</label>

        <select name="customer_id">

            <option value="">
                Walk-in Customer
            </option>

            <?php

            $customers = $conn->query(
                "SELECT id, name, phone
                 FROM customers
                 ORDER BY name ASC"
            );

            while ($customer = $customers->fetch_assoc()) {

            ?>

                <option value="<?php echo $customer['id']; ?>">

                    <?php

                    echo htmlspecialchars(
                        $customer['name']
                        . " - "
                        . $customer['phone']
                    );

                    ?>

                </option>

            <?php } ?>

        </select>



        <!-- PRODUCT -->

        <label>Product</label>

        <select
            name="product_id"
            id="product_id"
            required
        >

            <option value="">
                Select Product
            </option>

            <?php

            $products = $conn->query(
                "SELECT id, name, price, stock
                 FROM products
                 WHERE stock > 0
                 ORDER BY name ASC"
            );

            while ($product = $products->fetch_assoc()) {

            ?>

                <option
                    value="<?php echo $product['id']; ?>"
                    data-price="<?php echo $product['price']; ?>"
                    data-stock="<?php echo $product['stock']; ?>"
                >

                    <?php

                    echo htmlspecialchars(
                        $product['name']
                    );

                    ?>

                    -
                    ₹<?php echo number_format(
                        $product['price'],
                        2
                    ); ?>

                    -
                    Stock:
                    <?php echo $product['stock']; ?>

                </option>

            <?php } ?>

        </select>



        <!-- QUANTITY -->

        <label>Quantity</label>

        <input
            type="number"
            name="quantity"
            id="quantity"
            min="1"
            value="1"
            required
        >



        <!-- PRICE -->

        <label>Price</label>

        <input
            type="number"
            name="price"
            id="price"
            step="0.01"
            min="0"
            required
        >



        <!-- SALE DATE -->

        <label>Sale Date</label>

        <input
            type="date"
            name="sale_date"
            id="sale_date"
            value="<?php echo date('Y-m-d'); ?>"
            required
        >



        <!-- TOTAL -->

        <label>Total Amount</label>

        <input
            type="text"
            id="total"
            value="0.00"
            readonly
        >



        <br><br>

        <button
            type="submit"
            class="btn"
        >
            Save Sale
        </button>


        <a
            href="index.php"
            class="btn secondary"
        >
            Cancel
        </a>


    </form>

</div>



<script>

const productSelect =
    document.getElementById("product_id");

const priceInput =
    document.getElementById("price");

const quantityInput =
    document.getElementById("quantity");

const totalInput =
    document.getElementById("total");


// Product selection
productSelect.addEventListener("change", function () {

    const selected =
        this.options[this.selectedIndex];

    const price =
        selected.getAttribute("data-price");

    if (price) {

        priceInput.value = price;

    } else {

        priceInput.value = "";

    }

    calculateTotal();

});


// Quantity change
quantityInput.addEventListener(
    "input",
    calculateTotal
);


// Price change
priceInput.addEventListener(
    "input",
    calculateTotal
);


// Calculate total
function calculateTotal() {

    const quantity =
        parseFloat(quantityInput.value) || 0;

    const price =
        parseFloat(priceInput.value) || 0;

    const total =
        quantity * price;

    totalInput.value =
        total.toFixed(2);
}

</script>


<?php require "../partials/footer.php"; ?>