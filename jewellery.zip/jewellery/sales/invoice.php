<?php

require "../partials/header.php";
require "../config/db.php";

$id = (int)$_GET['id'];

$sale = $conn->query(
    "SELECT
        s.*,
        c.name AS customer,
        c.phone
     FROM sales s
     LEFT JOIN customers c
     ON c.id=s.customer_id
     WHERE s.id=$id"
)->fetch_assoc();

$items = $conn->query(
    "SELECT
        si.*,
        p.name
     FROM sale_items si
     LEFT JOIN products p
     ON p.id=si.product_id
     WHERE si.sale_id=$id"
);

?>

<div class="table-box">

<h1>💎 Jewellery Shop Invoice</h1>

<p>

<strong>Invoice:</strong>

<?php echo $sale['invoice_no']; ?>

&nbsp;&nbsp;

<strong>Date:</strong>

<?php echo $sale['sale_date']; ?>

</p>

<p>

<strong>Customer:</strong>

<?php

echo htmlspecialchars(
    $sale['customer'] ?? "Walk-in"
);

?>

&nbsp;&nbsp;

<strong>Phone:</strong>

<?php echo $sale['phone'] ?? ""; ?>

</p>

<table>

<tr>

<th>Item</th>
<th>Quantity</th>
<th>Price</th>
<th>Subtotal</th>

</tr>

<?php while ($item = $items->fetch_assoc()) { ?>

<tr>

<td>
<?php echo htmlspecialchars($item['name']); ?>
</td>

<td>
<?php echo $item['quantity']; ?>
</td>

<td>
₹<?php echo number_format($item['price'], 2); ?>
</td>

<td>
₹<?php echo number_format($item['subtotal'], 2); ?>
</td>

</tr>

<?php } ?>

</table>

<h2>

Total:

₹<?php echo number_format($sale['total'], 2); ?>

</h2>

<button
class="btn"
onclick="window.print()">

Print Invoice

</button>

</div>

<?php require "../partials/footer.php"; ?>