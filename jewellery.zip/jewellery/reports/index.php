<?php

require "../partials/header.php";
require "../config/db.php";

$salesResult = $conn->query(
    "SELECT COALESCE(SUM(total),0) AS total
     FROM sales"
);

$totalSales =
    $salesResult->fetch_assoc()['total'];


$purchaseResult = $conn->query(
    "SELECT COALESCE(SUM(total),0) AS total
     FROM purchases"
);

$totalPurchases =
    $purchaseResult->fetch_assoc()['total'];


$expenseResult = $conn->query(
    "SELECT COALESCE(SUM(amount),0) AS total
     FROM expenses"
);

$totalExpenses =
    $expenseResult->fetch_assoc()['total'];


$stockResult = $conn->query(
    "SELECT COALESCE(SUM(stock),0) AS total
     FROM products"
);

$totalStock =
    $stockResult->fetch_assoc()['total'];


$balance =
    $totalSales -
    $totalPurchases -
    $totalExpenses;

?>

<h1>Reports</h1>

<div class="cards">

<div class="card">

<h3>Total Sales</h3>

<div class="num">

₹<?php
echo number_format(
    $totalSales,
    2
);
?>

</div>

</div>


<div class="card">

<h3>Total Purchases</h3>

<div class="num">

₹<?php
echo number_format(
    $totalPurchases,
    2
);
?>

</div>

</div>


<div class="card">

<h3>Total Expenses</h3>

<div class="num">

₹<?php
echo number_format(
    $totalExpenses,
    2
);
?>

</div>

</div>


<div class="card">

<h3>Current Stock</h3>

<div class="num">

<?php echo $totalStock; ?>

</div>

</div>


<div class="card">

<h3>Sales - Purchases - Expenses</h3>

<div class="num">

₹<?php
echo number_format(
    $balance,
    2
);
?>

</div>

</div>

</div>

<div class="table-box">

<h2>Report Information</h2>

<p>

This is a basic mini-project financial summary.

The final amount is calculated as:

</p>

<p>

<strong>
Sales - Purchases - Expenses
</strong>

</p>

<p>

It is intended for demonstration purposes and
is not a complete accounting statement.

</p>

</div>

<?php require "../partials/footer.php"; ?>