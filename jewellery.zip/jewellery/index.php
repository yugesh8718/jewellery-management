<?php

session_start();

require_once "config/db.php";

if (isset($_SESSION['user'])) {
    header("Location: dashboard.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare(
        "SELECT id, username, password
         FROM users
         WHERE username = ?
         LIMIT 1"
    );

    $stmt->bind_param("s", $username);

    $stmt->execute();

    $result = $stmt->get_result();

    $user = $result->fetch_assoc();

    if ($user && $password === $user['password']) {

        $_SESSION['user'] = $user['username'];

        header("Location: dashboard.php");
        exit();

    } else {

        $error = "Invalid username or password";
    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <title>Jewellery Management System</title>

    <link rel="stylesheet"
          href="assets/style.css">

</head>

<body class="login-page">

<div class="login-box">

    <h1>💎 Jewellery Shop</h1>

    <p>Management System</p>

    <?php if ($error != "") { ?>

        <div class="alert danger">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php } ?>

    <form method="POST">

        <label>Username</label>

        <input
            type="text"
            name="username"
            required
        >

        <label>Password</label>

        <input
            type="password"
            name="password"
            required
        >

        <button class="btn full">
            Login
        </button>

    </form>

    <p class="login-help">
        Username: admin<br>
        Password: admin123
    </p>

</div>

</body>
</html>