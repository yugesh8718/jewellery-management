<?php

require "../partials/header.php";
require "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $metal = $_POST['metal_type'];
    $purity = $_POST['purity'];
    $rate = $_POST['rate'];
    $date = $_POST['rate_date'];

    $stmt = $conn->prepare(
        "INSERT INTO metal_rates
        (metal_type, purity, rate, rate_date)
        VALUES (?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "ssds",
        $metal,
        $purity,
        $rate,
        $date
    );

    $stmt->execute();

    header("Location: index.php");
    exit();
}

?>

<h1>Add Metal Price</h1>

<div class="form-box">

<form method="POST">

<label>Metal</label>

<select name="metal_type">

<option value="Gold">Gold</option>
<option value="Silver">Silver</option>

</select>

<label>Purity</label>

<input
    type="text"
    name="purity"
    placeholder="22K / 24K / 999"
>

<label>Rate per Gram</label>

<input
    type="number"
    step="0.01"
    name="rate"
    required
>

<label>Date</label>

<input
    type="date"
    name="rate_date"
    value="<?php echo date('Y-m-d'); ?>"
    required
>

<br>

<button class="btn green">
    Save Price
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>