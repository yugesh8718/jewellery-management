<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Daily Metal Prices</h1>

<a class="btn" href="add.php">
    + Add Price
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Date</th>
<th>Metal</th>
<th>Purity</th>
<th>Rate / Gram</th>
</tr>

<?php

$result = $conn->query(
    "SELECT *
     FROM metal_rates
     ORDER BY rate_date DESC, id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td><?php echo $row['rate_date']; ?></td>

<td><?php echo $row['metal_type']; ?></td>

<td><?php echo $row['purity']; ?></td>

<td>
₹<?php echo number_format($row['rate'], 2); ?>
</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>