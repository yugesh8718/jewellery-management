<?php

require "partials/header.php";
require "config/db.php";

function countRows($conn, $table)
{
    $result = $conn->query(
        "SELECT COUNT(*) AS total FROM $table"
    );

    return $result->fetch_assoc()['total'];
}

$customers = countRows($conn, "customers");

$products = countRows($conn, "products");

$stockResult = $conn->query(
    "SELECT COALESCE(SUM(stock),0) AS total
     FROM products"
);

$stock = $stockResult->fetch_assoc()['total'];

$salesResult = $conn->query(
    "SELECT COALESCE(SUM(total),0) AS total
     FROM sales
     WHERE sale_date = CURDATE()"
);

$todaySales = $salesResult->fetch_assoc()['total'];

$goldResult = $conn->query(
    "SELECT rate
     FROM metal_rates
     WHERE metal_type = 'Gold'
     ORDER BY rate_date DESC, id DESC
     LIMIT 1"
);

$gold = $goldResult->fetch_assoc();

$silverResult = $conn->query(
    "SELECT rate
     FROM metal_rates
     WHERE metal_type = 'Silver'
     ORDER BY rate_date DESC, id DESC
     LIMIT 1"
);

$silver = $silverResult->fetch_assoc();

?>

<div class="page-head">

    <h1>Dashboard</h1>

</div>

<div class="cards">

    <div class="card">
        <h3>Customers</h3>
        <div class="num">
            <?php echo $customers; ?>
        </div>
    </div>

    <div class="card">
        <h3>Products</h3>
        <div class="num">
            <?php echo $products; ?>
        </div>
    </div>

    <div class="card">
        <h3>Total Stock</h3>
        <div class="num">
            <?php echo $stock; ?>
        </div>
    </div>

    <div class="card">
        <h3>Today's Sales</h3>
        <div class="num">
            ₹<?php echo number_format($todaySales, 2); ?>
        </div>
    </div>

    <div class="card">
        <h3>Gold Rate</h3>
        <div class="num">
            ₹<?php echo number_format($gold['rate'] ?? 0, 2); ?>
        </div>
    </div>

    <div class="card">
        <h3>Silver Rate</h3>
        <div class="num">
            ₹<?php echo number_format($silver['rate'] ?? 0, 2); ?>
        </div>
    </div>

</div>

<div class="table-box">

    <h2>Recent Sales</h2>

    <table>

        <tr>
            <th>Invoice</th>
            <th>Customer</th>
            <th>Date</th>
            <th>Total</th>
        </tr>

        <?php

        $sales = $conn->query(
            "SELECT s.*, c.name AS customer
             FROM sales s
             LEFT JOIN customers c
             ON c.id = s.customer_id
             ORDER BY s.id DESC
             LIMIT 10"
        );

        while ($row = $sales->fetch_assoc()) {

        ?>

        <tr>

            <td>
                <?php echo htmlspecialchars($row['invoice_no']); ?>
            </td>

            <td>
                <?php
                echo htmlspecialchars(
                    $row['customer'] ?? 'Walk-in'
                );
                ?>
            </td>

            <td>
                <?php echo $row['sale_date']; ?>
            </td>

            <td>
                ₹<?php echo number_format($row['total'], 2); ?>
            </td>

        </tr>

        <?php } ?>

    </table>

</div>

<?php require "partials/footer.php"; ?>