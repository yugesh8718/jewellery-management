<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Suppliers</h1>

<a class="btn" href="add.php">
+ Add Supplier
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Name</th>
<th>Phone</th>
<th>Email</th>
<th>Address</th>
<th>Action</th>
</tr>

<?php

$result = $conn->query(
    "SELECT *
     FROM suppliers
     ORDER BY id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td><?php echo htmlspecialchars($row['name']); ?></td>

<td><?php echo $row['phone']; ?></td>

<td><?php echo $row['email']; ?></td>

<td><?php echo htmlspecialchars($row['address']); ?></td>

<td>

<a class="btn"
href="edit.php?id=<?php echo $row['id']; ?>">
Edit
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>