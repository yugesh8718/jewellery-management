<?php

require "../partials/header.php";
require "../config/db.php";

$id = (int)$_GET['id'];

$stmt = $conn->prepare(
    "SELECT *
     FROM suppliers
     WHERE id=?"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$supplier = $stmt->get_result()->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $stmt = $conn->prepare(
        "UPDATE suppliers
         SET name=?, phone=?, email=?, address=?
         WHERE id=?"
    );

    $stmt->bind_param(
        "ssssi",
        $_POST['name'],
        $_POST['phone'],
        $_POST['email'],
        $_POST['address'],
        $id
    );

    $stmt->execute();

    header("Location: index.php");
    exit();
}

?>

<h1>Edit Supplier</h1>

<div class="form-box">

<form method="POST">

<label>Name</label>

<input
name="name"
value="<?php echo htmlspecialchars($supplier['name']); ?>"
required
>

<label>Phone</label>

<input
name="phone"
value="<?php echo htmlspecialchars($supplier['phone']); ?>"
>

<label>Email</label>

<input
name="email"
value="<?php echo htmlspecialchars($supplier['email']); ?>"
>

<label>Address</label>

<textarea name="address"><?php
echo htmlspecialchars($supplier['address']);
?></textarea>

<br>

<button class="btn green">
Update Supplier
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>