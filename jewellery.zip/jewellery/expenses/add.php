<?php

require "../partials/header.php";
require "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = $_POST['title'];

    $amount = $_POST['amount'];

    $date = $_POST['expense_date'];

    $description = $_POST['description'];

    $stmt = $conn->prepare(
        "INSERT INTO expenses
        (title, amount, expense_date, description)
        VALUES (?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "sdss",
        $title,
        $amount,
        $date,
        $description
    );

    $stmt->execute();

    header("Location: index.php");

    exit();
}

?>

<h1>Add Expense</h1>

<div class="form-box">

<form method="POST">

<label>Expense Title</label>

<input
name="title"
required
>

<label>Amount</label>

<input
type="number"
step="0.01"
name="amount"
required
>

<label>Date</label>

<input
type="date"
name="expense_date"
value="<?php echo date('Y-m-d'); ?>"
>

<label>Description</label>

<textarea name="description"></textarea>

<br>

<button class="btn green">
Save Expense
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>