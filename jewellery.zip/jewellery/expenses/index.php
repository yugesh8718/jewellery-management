<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Expenses</h1>

<a class="btn" href="add.php">
+ Add Expense
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Title</th>
<th>Amount</th>
<th>Date</th>
<th>Description</th>
</tr>

<?php

$result = $conn->query(
    "SELECT *
     FROM expenses
     ORDER BY id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td>
<?php echo htmlspecialchars($row['title']); ?>
</td>

<td>
₹<?php echo number_format($row['amount'], 2); ?>
</td>

<td>
<?php echo $row['expense_date']; ?>
</td>

<td>
<?php echo htmlspecialchars($row['description']); ?>
</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>