<?php

require "../partials/header.php";
require "../config/db.php";

$suppliers = $conn->query(
    "SELECT *
     FROM suppliers
     ORDER BY name"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $supplier = (int)$_POST['supplier_id'];

    $date = $_POST['purchase_date'];

    $total = $_POST['total'];

    $stmt = $conn->prepare(
        "INSERT INTO purchases
        (supplier_id, purchase_date, total)
        VALUES (?, ?, ?)"
    );

    $stmt->bind_param(
        "isd",
        $supplier,
        $date,
        $total
    );

    $stmt->execute();

    header("Location: index.php");

    exit();
}

?>

<h1>Add Purchase</h1>

<div class="form-box">

<form method="POST">

<label>Supplier</label>

<select name="supplier_id" required>

<?php while ($supplier = $suppliers->fetch_assoc()) { ?>

<option value="<?php echo $supplier['id']; ?>">

<?php echo htmlspecialchars($supplier['name']); ?>

</option>

<?php } ?>

</select>

<label>Purchase Date</label>

<input
type="date"
name="purchase_date"
value="<?php echo date('Y-m-d'); ?>"
required
>

<label>Total Amount</label>

<input
type="number"
step="0.01"
name="total"
required
>

<br>

<button class="btn green">
Save Purchase
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>