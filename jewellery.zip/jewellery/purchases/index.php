<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Purchases</h1>

<a class="btn" href="add.php">
+ Add Purchase
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Supplier</th>
<th>Date</th>
<th>Total</th>
</tr>

<?php

$result = $conn->query(
    "SELECT
        p.*,
        s.name AS supplier
     FROM purchases p
     LEFT JOIN suppliers s
     ON s.id=p.supplier_id
     ORDER BY p.id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td>
<?php echo htmlspecialchars($row['supplier']); ?>
</td>

<td>
<?php echo $row['purchase_date']; ?>
</td>

<td>
₹<?php echo number_format($row['total'], 2); ?>
</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>