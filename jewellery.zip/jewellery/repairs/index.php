<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

<h1>Repair Management</h1>

<a class="btn" href="add.php">
+ New Repair
</a>

</div>

<div class="table-box">

<table>

<tr>
<th>Customer</th>
<th>Item</th>
<th>Status</th>
<th>Charge</th>
<th>Date</th>
</tr>

<?php

$result = $conn->query(
    "SELECT
        r.*,
        c.name AS customer
     FROM repairs r
     LEFT JOIN customers c
     ON c.id=r.customer_id
     ORDER BY r.id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td>
<?php echo htmlspecialchars($row['customer']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['item_name']); ?>
</td>

<td>

<span class="badge">

<?php echo $row['status']; ?>

</span>

</td>

<td>
₹<?php echo number_format($row['charge'], 2); ?>
</td>

<td>
<?php echo $row['received_date']; ?>
</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>