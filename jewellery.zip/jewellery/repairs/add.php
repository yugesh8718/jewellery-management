<?php

require "../partials/header.php";
require "../config/db.php";

$customers = $conn->query(
    "SELECT *
     FROM customers
     ORDER BY name"
);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $customer = (int)$_POST['customer_id'];

    $item = $_POST['item_name'];

    $description = $_POST['description'];

    $status = $_POST['status'];

    $charge = $_POST['charge'];

    $date = $_POST['received_date'];

    $stmt = $conn->prepare(
        "INSERT INTO repairs
        (
            customer_id,
            item_name,
            description,
            status,
            charge,
            received_date
        )
        VALUES (?, ?, ?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "isssds",
        $customer,
        $item,
        $description,
        $status,
        $charge,
        $date
    );

    $stmt->execute();

    header("Location: index.php");

    exit();
}

?>

<h1>New Repair</h1>

<div class="form-box">

<form method="POST">

<label>Customer</label>

<select name="customer_id" required>

<?php while ($customer = $customers->fetch_assoc()) { ?>

<option value="<?php echo $customer['id']; ?>">

<?php echo htmlspecialchars($customer['name']); ?>

</option>

<?php } ?>

</select>

<label>Item Name</label>

<input
name="item_name"
required
>

<label>Description</label>

<textarea name="description"></textarea>

<label>Status</label>

<select name="status">

<option>Received</option>

<option>In Progress</option>

<option>Completed</option>

<option>Delivered</option>

</select>

<label>Repair Charge</label>

<input
type="number"
step="0.01"
name="charge"
value="0"
>

<label>Received Date</label>

<input
type="date"
name="received_date"
value="<?php echo date('Y-m-d'); ?>"
>

<br>

<button class="btn green">
Save Repair
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>