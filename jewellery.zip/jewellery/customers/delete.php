<?php

require "../config/db.php";

$id = (int)$_GET['id'];

$stmt = $conn->prepare(
    "DELETE FROM customers
     WHERE id = ?"
);

$stmt->bind_param("i", $id);

$stmt->execute();

header("Location: index.php");

exit();

?>