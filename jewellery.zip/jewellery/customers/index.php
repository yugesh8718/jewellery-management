<?php

require "../partials/header.php";
require "../config/db.php";

?>

<div class="page-head">

    <h1>Customers</h1>

    <a class="btn" href="add.php">
        + Add Customer
    </a>

</div>

<div class="table-box">

<table>

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Phone</th>
    <th>Email</th>
    <th>Address</th>
    <th>Actions</th>
</tr>

<?php

$result = $conn->query(
    "SELECT *
     FROM customers
     ORDER BY id DESC"
);

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td><?php echo $row['id']; ?></td>

<td>
<?php echo htmlspecialchars($row['name']); ?>
</td>

<td><?php echo $row['phone']; ?></td>

<td>
<?php echo htmlspecialchars($row['email']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['address']); ?>
</td>

<td class="actions">

<a class="btn"
   href="edit.php?id=<?php echo $row['id']; ?>">
   Edit
</a>

<a class="btn red"
   href="delete.php?id=<?php echo $row['id']; ?>"
   onclick="return confirm('Delete customer?');">
   Delete
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<?php require "../partials/footer.php"; ?>