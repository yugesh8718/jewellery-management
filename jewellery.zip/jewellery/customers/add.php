<?php

require "../partials/header.php";
require "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $stmt = $conn->prepare(
        "INSERT INTO customers
        (name, phone, email, address)
        VALUES (?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "ssss",
        $name,
        $phone,
        $email,
        $address
    );

    $stmt->execute();

    header("Location: index.php");
    exit();
}

?>

<h1>Add Customer</h1>

<div class="form-box">

<form method="POST">

<label>Name</label>

<input
    type="text"
    name="name"
    required
>

<label>Phone</label>

<input
    type="text"
    name="phone"
    required
>

<label>Email</label>

<input
    type="email"
    name="email"
>

<label>Address</label>

<textarea name="address"></textarea>

<br>

<button class="btn green">
    Save Customer
</button>

<a class="btn gray" href="index.php">
    Cancel
</a>

</form>

</div>

<?php require "../partials/footer.php"; ?>