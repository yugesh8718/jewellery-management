<?php

require "../partials/header.php";
require "../config/db.php";

$id = (int)$_GET['id'];

$stmt = $conn->prepare(
    "SELECT *
     FROM customers
     WHERE id = ?"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$customer = $stmt->get_result()->fetch_assoc();

if (!$customer) {
    die("Customer not found");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $stmt = $conn->prepare(
        "UPDATE customers
         SET name=?, phone=?, email=?, address=?
         WHERE id=?"
    );

    $stmt->bind_param(
        "ssssi",
        $name,
        $phone,
        $email,
        $address,
        $id
    );

    $stmt->execute();

    header("Location: index.php");
    exit();
}

?>

<h1>Edit Customer</h1>

<div class="form-box">

<form method="POST">

<label>Name</label>

<input
    name="name"
    value="<?php echo htmlspecialchars($customer['name']); ?>"
    required
>

<label>Phone</label>

<input
    name="phone"
    value="<?php echo htmlspecialchars($customer['phone']); ?>"
    required
>

<label>Email</label>

<input
    name="email"
    value="<?php echo htmlspecialchars($customer['email']); ?>"
>

<label>Address</label>

<textarea name="address"><?php
echo htmlspecialchars($customer['address']);
?></textarea>

<br>

<button class="btn green">
    Update Customer
</button>

</form>

</div>

<?php require "../partials/footer.php"; ?>