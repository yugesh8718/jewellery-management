<?php

require_once __DIR__ . '/../config/auth.php';

?>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Jewellery Management System</title>

    <link rel="stylesheet"
          href="/jewellery/assets/style.css">

</head>

<body>

<div class="layout">

    <aside class="sidebar">

        <h2>💎 Jewellery</h2>

        <a href="/jewellery/dashboard.php">
            Dashboard
        </a>

        <a href="/jewellery/customers/index.php">
            Customers
        </a>

        <a href="/jewellery/products/index.php">
            Products
        </a>

        <a href="/jewellery/prices/index.php">
            Daily Prices
        </a>

        <a href="/jewellery/sales/index.php">
            Sales
        </a>

        <a href="/jewellery/purchases/index.php">
            Purchases
        </a>

        <a href="/jewellery/suppliers/index.php">
            Suppliers
        </a>

        <a href="/jewellery/repairs/index.php">
            Repairs
        </a>

        <a href="/jewellery/expenses/index.php">
            Expenses
        </a>

        <a href="/jewellery/reports/index.php">
            Reports
        </a>

        <a href="/jewellery/logout.php">
            Logout
        </a>

    </aside>

    <main class="content">

        <div class="topbar">

            Welcome,
            <strong>
                <?php echo htmlspecialchars($_SESSION['user']); ?>
            </strong>

        </div>